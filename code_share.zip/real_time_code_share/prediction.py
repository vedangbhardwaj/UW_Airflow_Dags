import logging
import boto3
import pandas as pd
import snowflake.connector
import logging
from datetime import datetime, timedelta
from airflow.models import Variable
from snowflake.connector.pandas_tools import pd_writer
from snowflake.sqlalchemy import URL
from sqlalchemy import create_engine
from uw_utility_functions import write_to_snowflake
from s3fs.core import S3FileSystem
import scorecardpy as sc
from uw_sql_queries import Get_query
import os
import json
import yaml


with open("config.yml") as config_file:
    config_var = yaml.full_load(config_file)

missing_value_num = config_var["missing_value_num"]
missing_value_cat = config_var["missing_value_cat"]
IV_threshold = config_var["IV_threshold"]  ### threshold for IV (IV should be accepted
var_threshold = config_var["var_threshold"]
ID_cols = config_var["ID_cols"]
input_path = config_var["input_path"]
data_path = config_var["data_path"]
model_path = config_var["model_path"]
start_date = "2022-12-15"
end_date = "2022-12-16"

config = Variable.get("underwriting_dags", deserialize_json=True)
s3 = boto3.resource("s3")
s3_bucket = config["s3_bucket"]

def read_file(bucket_name, file_name):
    obj = s3.meta.client.get_object(Bucket=bucket_name, Key=file_name)
    return obj["Body"]

feature_list = pd.read_csv(
    read_file(s3_bucket, input_path + "KB_transaction_module_variables.csv")
)

conn = snowflake.connector.connect(
    user=config["user"],
    password=config["password"],
    account=config["account"],
    # user=os.environ.get('SNOWFLAKE_UNAME'),
    # password=os.environ.get('SNOWFLAKE_PASS'),
    # account=os.environ.get('SNOWFLAKE_ACCOUNT'),
    role=config["role"],
    warehouse=config["warehouse"],
    database=config["database"],
    insecure_mode=True,
)
cur = conn.cursor()

def get_raw_data(start_date, end_date):
    sql_cmd = Get_query("KB_TXN_MODULE").get_raw_data.format(
        sd=start_date, ed=end_date
    )
    cur.execute(sql_cmd)
    df = pd.DataFrame(cur.fetchall())
    colnames = [desc[0] for desc in cur.description]
    df.columns = [i for i in colnames]
    return df

cat_col = list(feature_list["variables"][feature_list["Type"] == "Categorical"])
num_col = list(feature_list["variables"][feature_list["Type"] == "Numerical"])

def var_type(var1):
    if var1 in cat_col:
        return "Categorical"
    elif var1 in num_col:
        return "Numerical"
    else:
        return "Others"

def missing_ind_convert_num(df):
    for var in df.columns:
        if var_type(var) == "Numerical":
            df[var] = pd.to_numeric(df[var])
    for var in df.columns:
        if var_type(var) == "Categorical":
            # df[var] = df[var].replace("--", missing_value_cat)
            df[var] = pd.Categorical(df[var])
    return df


def generate_prediction(input):
    import pickle

    import numpy as np
    import statsmodels.api as sm

    pickled_model = pickle.loads(
        s3.Bucket(s3_bucket).Object(f"{model_path}Model_xgb.pkl").get()["Body"].read()
    )
    data = pd.read_json(input)
    data1 = data[keep_var_list]
    data["pred_train"] = pickled_model.predict_proba(data1)[:, 1]

    data["logodds_score"] = np.log(data["pred_train"] / (1 - data["pred_train"]))

    model_xgb_calib = pickle.loads(
        s3.Bucket(s3_bucket)
        .Object(f"{model_path}Model_LR_calibration_xgb.pkl")
        .get()["Body"]
        .read()
    )

    data["pred_train_xgb"] = model_xgb_calib.predict(
        sm.add_constant(data["logodds_score"])
    )

    return data.to_json(orient='records')[1:-1].replace('},{', '} {')

data = get_raw_data(start_date, end_date)
data = missing_ind_convert_num(data)

XGB_keep_var_list = pd.read_csv(
    read_file(s3_bucket, model_path + "XGBoost_feature_list.csv")
)
keep_var_list = list(XGB_keep_var_list["variables"])

input_data = data.to_json(orient='records')
input_data

generate_prediction(input_data)
result = generate_prediction(input_data)
result

